import './App.css';
import photo from './avatar.jpg';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; 
import Getdata from './Getdata'; 
import Update from './Update'; 
import ShoppingCard from './Shopping/ShoppingCard';
import ContactForm from './ContactForm';

function App() {
  return (
    <Router> 
      <div className="App">
        <h1>Hi !! I'm Shreya Songare</h1>
        <img src={photo} alt="avatar" />
        <p>slwehglgskn,ldejtle,nn dnsf en.k;etp4;jsdn,dsw,fks'p3k5tngnfs, ar,w/s'</p>
      </div> 
      

      <ShoppingCard />
      <ContactForm/>

      <Routes> 
        <Route path="/" element={<Getdata />} /> 
        <Route path="/updated/:_id" element={<Update />} /> 
      </Routes>

    </Router>
  );
}

export default App;
